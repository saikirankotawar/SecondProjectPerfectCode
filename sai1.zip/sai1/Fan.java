import java.lang.System;
import java.lang.String;
class Fan
{
	String color;
	String brand;
	int price;
	{
		System.out.println("blow air");
}
		public static void main(String[] args)
	{
		Fan saikiran=new Fan();
		saikiran.color="white";
		saikiran.brand="havells";
		saikiran.price=5000;
	}
}
