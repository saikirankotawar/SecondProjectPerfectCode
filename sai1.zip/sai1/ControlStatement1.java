import java.lang.System;
import java.lang.String;
import java.util.Scanner;
class ControlStatement1
{
	public static void main(String[] args)
	{
     Scanner sc=new Scanner(System.in);
	 System.out.println("enter start value");
	 int startvalue=sc.nextInt();
	 System.out.println("enter end value");
	 int endvalue=sc.nextInt();
	 while(startvalue<=endvalue)
	{
    System.out.println(startvalue);
	startvalue=startvalue+1;
	}
	}
}
