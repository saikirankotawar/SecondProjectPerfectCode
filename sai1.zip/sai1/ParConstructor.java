class ParConstructor
{
	int i;
	ParConstructor(int s)
	{
		i=s;
}
public static void main(String[] args)
	{
ParConstructor sai=new ParConstructor(100);
System.out.println(sai.i);
}
}