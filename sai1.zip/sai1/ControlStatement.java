import java.lang.System;
import java.lang.String;
class ControlStatement
{
	public static void main(String[] args)
{
	int age=Integer.parseInt(args[0]);
	if(age>18)
	{
	System.out.println("eligible to vote");
	}
	else
	{
	System.out.println("not eligible to vote");
    }
}
}