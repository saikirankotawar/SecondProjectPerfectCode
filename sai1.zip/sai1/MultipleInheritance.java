class A
{
	System.out.println("A");
}
class B
{
	System.out.println("B");
}
class C
{
	System.out.println("C");
}
class D extends A,B,C
{
	D s=new D();
}
}