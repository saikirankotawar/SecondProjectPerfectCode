import java.lang.System;
import java.lang.String;
import java.util.Scanner;
class Switch
{
	public static void main(String[] args)
	{
		System.out.println("---------Menu-----------");
		System.out.println("------------------------");
		System.out.println("--------Veg Biryani-----");
		System.out.println("--------Panner tika-----");
		System.out.println("------------------------");
		Scanner sc=new Scanner(System.in);
        System.out.println("enter your Choice");
		int Choice=sc.nextInt();
		switch(Choice)
		{
		case 1: System.out.println("you have selected Veg biryanai and price is 200");
		        break;
        case 2: System.out.println("you have selected Panner tika and price is 250");
		        break;
		default: System.out.println("not available");
		}
	}
}