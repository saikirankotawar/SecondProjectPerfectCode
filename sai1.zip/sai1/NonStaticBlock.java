import java.lang.System;
import java.lang.String;
class NonStaticBlock
{
{
	System.out.println("NonStaticBlock");
}
public static void main(String[] args)
{
	System.out.println("main method");
	new NonStaticBlock();
}
}