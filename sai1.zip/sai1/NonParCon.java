class NonParCon
{
	  int i;
	  NonParCon()
	{
		  System.out.println("Non Par Con Called");
}
public static void main(String[] args)
	{
	NonParCon sai=new NonParCon();
    System.out.println(sai.i);
}
}