import java.lang.System;
import java.lang.String;
import java.util.Scanner;
class ControlStatement2
{
	public static void main(String[] args)
	{
		int i=20;
		do
		{
			System.out.println(i);
			i=i+1;
		}while(i<25);

}
}