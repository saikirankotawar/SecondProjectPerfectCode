class BasicCalci
{
	void add(int a,int b)
	{
		System.out.println(a+b);
}
     void sub(int a,int b)
	{
		 System.out.println(a-b);
	}
	void mul(int a,int b)
	{
		  System.out.println(a*b);
	}
	void div(int a,int b)
	{
		System.out.println(a/b);
	}
class Scientific extends BasicCalci
{
	public void square(int a)
	{
		System.out.println(a*a);
}
    public void cube(int a)
	{
		System.out.println(a*a*a);
	}
}
class Testcal
{
	public static void main(String[] args)
	{
    Scientific sc=new Scientific();
	sc.square(30);
	sc.cube(3);
	}
}
