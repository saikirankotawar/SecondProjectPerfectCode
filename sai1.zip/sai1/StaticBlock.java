import java.lang.System;
import java.lang.String;
class StaticBlock
{
	public static void main(String[] args)
{
     System.out.println("main method");
}
static
{
    System.out.println("Static method called");
}
}