class Constructor
{
	int i;
	public static void main(String[] args)
	{
		Constructor s=new Constructor();
		System.out.println(s.i);
}
}