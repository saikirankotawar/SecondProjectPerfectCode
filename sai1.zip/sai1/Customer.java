class Customer
{
	String username;
	Date    dob;
	void Viewproducts()
	{
		System.out.println("View products");
}
	void buy()
	{
		System.out.println("buy");
	}
	product static void main(String[] args)
	{
		Customer sai=new Customer();
		sai.username="saikiran";
		sai.dob=07/03/1994;
	}
}
