package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.backend.dao.SupplierDao;
import com.backend.model.Supplier;

@Controller
public class SupplierController {

	@Autowired
	SupplierDao supplierDao;
	@RequestMapping("/test3")
	public String Test3( )
	{
		System.out.println("iam inside the suplier");
		Supplier supplier=new Supplier( );
		supplier.setSupplierId(908);
		supplier.setSuppliername("saicharan");
		supplier.setSupplieraddress("Banglore");
		supplierDao.addSupplier(supplier);
		return "login";
	}
	}

