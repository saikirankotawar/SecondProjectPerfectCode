package com.backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Supplier {

	@Id@GeneratedValue
	private int SupplierId;
	private String Suppliername;
	private String Supplieraddress;
	public int getSupplierId() {
		return SupplierId;
	}
	public void setSupplierId(int supplierId) {
		SupplierId = supplierId;
	}
	public String getSuppliername() {
		return Suppliername;
	}
	public void setSuppliername(String suppliername) {
		Suppliername = suppliername;
	}
	public String getSupplieraddress() {
		return Supplieraddress;
	}
	public void setSupplieraddress(String supplieraddress) {
		Supplieraddress = supplieraddress;
	}
	
	
}
