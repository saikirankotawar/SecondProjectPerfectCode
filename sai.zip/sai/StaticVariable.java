class StaticVariable
{
	int i=25;
	static int k;
	void m1()
	{
		int i=100;
		System.out.println(i);
	}
	public static void main(String[] args)
	{
		StaticVariable b=new StaticVariable();
		b.m1();
		StaticVariable n=new StaticVariable();
		System.out.println(n.a);
		System.out.println(StaticVariable.k);
	}
}