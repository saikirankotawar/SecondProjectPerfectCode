class LocalVariable
{
	void m1()
	{
		int i=100;
		System.out.println(i);
	}
	public static void main(String[] args)
	{
    LocalVariable l=new LocalVariable();
	l.m1();
}
}