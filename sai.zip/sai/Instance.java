import java.lang.System;
import java.lang.String;
class Instance
{
void m1()
{
System.out.println("m1 method");
}
public static void main(String[] args)
{
Instance a=new Instance();
a.m1();
}
}