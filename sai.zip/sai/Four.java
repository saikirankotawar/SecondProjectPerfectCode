class Four
{
	static void display()
	{
		System.out.println(add(10,20));
		System.out.println(score());
		sub(20,10);
	}
	public static void main(String[] args)
	{
		display();
	
}
}