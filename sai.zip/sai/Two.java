class Two
{
	static String score()
	{
		return "100/9";
	}
	public static void main(String[] args)
	{
		String c=Two.score();
		System.out.println(c);
}
}