class InstanceVariable
{
	int i;
	void m1()
	{
		int i=100;
		System.out.println(i);
	}
	public static void main(String[] args)
	{
		InstanceVariable i=new InstanceVariable();
		i.m1();
		System.out.println(i);
	}
}