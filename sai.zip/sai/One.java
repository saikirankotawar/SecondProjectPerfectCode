class One
{
	static int add(int a,int b)
{
		return a+b;
}
public static void main(String[] args)
{
	int a=One.add(10,20);
	System.out.println(a);
}
}

