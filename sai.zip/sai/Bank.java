class Bank
{
	static void withdraw()
	{
	System.out.println("withdraw called");
	}
	static void balance()
	{
	System.out.println("balance called");
	}
	static void deposite()
    { 
    System.out.println("deposite called");
	}
	public static void main(String[] args)
	{
     deposite();
	}

}