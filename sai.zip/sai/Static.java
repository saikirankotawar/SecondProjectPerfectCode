import java.lang.System;
import java.lang.String;
class Static
{
 static void m1()
{
System.out.println("m1 method");
}
public static void main(String[] args)
{
Static.m1();
}
}