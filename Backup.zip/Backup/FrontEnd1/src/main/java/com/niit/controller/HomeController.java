package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String index()
	{
		System.out.println("I am a controller");
		return "index";
	}
	@RequestMapping("/login")
	public String login()
	{
		System.out.println("login page is logged!!!");
		return "login";
	}
	@RequestMapping("/Register")
	public String request()
	{
		System.out.println("Register page is logged!!!");
		return "Register";
	}
	@RequestMapping("/Aboutus")
	public String Aboutus()
	{
		System.out.println("About us called");
		return "Aboutus";
	}
	@RequestMapping("/Service")
	public String Service()
	{
		System.out.println("Service is called");
		return "Service";
	}
	@RequestMapping("/contactus")
     public String contactUs()
		{
			System.out.println("conatactus is called");
			return "contactus";
		}
	@RequestMapping("/Connectwithus")
	public String contactwithus()
	{
		System.out.println("connectactwithus is called");
		return "Connectwithus";
	}
	}
